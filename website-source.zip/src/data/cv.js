import fs from 'node:fs';
import path from 'node:path';

// Only the output name is fixed. The owner may use any PDF name in cv-upload/.
// Both the upload folder and legacy PDF stay outside website-source.zip.
export const cvFilename = 'Ahmed-Iqdymat-Academic-CV.pdf';
export function findPublicCV(root = process.cwd()) {
  const folder = path.join(root, 'cv-upload');
  if (fs.existsSync(folder)) {
    const entries = fs.readdirSync(folder, {withFileTypes: true});
    const pdfs = entries.filter(entry => /\.pdf$/i.test(entry.name));
    if (pdfs.length !== 1 || !pdfs[0].isFile()) {
      throw new Error('cv-upload must contain exactly one regular PDF file. Keep the intended public CV only.');
    }
    return path.join(folder, pdfs[0].name);
  }
  // Compatibility for existing checkouts before the upload folder is introduced.
  const legacy = path.join(root, cvFilename);
  return fs.existsSync(legacy) ? legacy : null;
}
export function readPublicCV(root = process.cwd()) {
  const source = findPublicCV(root);
  if (!source) return null;
  if (fs.statSync(source).size > 10 * 1024 * 1024) throw new Error('Public CV must be under 10 MB.');
  const bytes = fs.readFileSync(source);
  if (bytes.subarray(0, 5).toString() !== '%PDF-' || !bytes.subarray(-1024).includes(Buffer.from('%%EOF'))) {
    throw new Error('The uploaded public CV is not a complete PDF.');
  }
  return bytes;
}
export const cvPdf = readPublicCV() ? `/cv/${cvFilename}` : null;
