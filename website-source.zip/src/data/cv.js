import fs from 'node:fs';
import path from 'node:path';

// Kept outside website-source.zip so a new source upload cannot overwrite the CV.
export const cvFilename = 'Ahmed-Iqdymat-Academic-CV.pdf';
export const cvSource = path.resolve(cvFilename);
export const cvUploadUrl = 'https://github.com/AHMED-IQDYMAT/AHMED-IQDYMAT.github.io/upload/main';
export function readPublicCV() {
  if (!fs.existsSync(cvSource)) return null;
  if (fs.statSync(cvSource).size > 10 * 1024 * 1024) throw new Error('Public CV must be under 10 MB.');
  const bytes = fs.readFileSync(cvSource);
  if (bytes.subarray(0, 5).toString() !== '%PDF-' || !bytes.subarray(-1024).includes(Buffer.from('%%EOF'))) {
    throw new Error('The uploaded public CV is not a complete PDF.');
  }
  return bytes;
}
export const cvPdf = readPublicCV() ? `/cv/${cvFilename}` : null;
