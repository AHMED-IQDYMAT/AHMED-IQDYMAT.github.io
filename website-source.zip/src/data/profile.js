import {cvPdf} from './cv.js';
export const profile = {
 name: 'Ahmed Iqdymat', displayName: 'AHMED IQDYMAT', institutionUrl: 'https://upb.ro/', professionalEmail: 'Ahmed.Iqdymat@gmail.com', cvPdf, updated: 'September 2026', title: 'Automation & Control Systems Engineer', status: 'PhD Candidate in Systems Engineering',
 institution: 'National University of Science and Technology POLITEHNICA Bucharest', department: 'Department of Automation and Industrial Informatics', location: 'Bucharest, Romania', email: 'ahmed.iqdymat@stud.acs.upb.ro', portrait: '/images/ahmed-iqdymat.jpeg',
 introduction: 'Ahmed Iqdymat is an Automation and Control Systems Engineer and PhD Candidate in Systems Engineering. His academic and research interests include automation and control systems, intelligent control, robotics, reinforcement learning, system modelling and simulation, and AI-based methods for industrial automation.',
 biography: 'Alongside his academic research, his engineering background encompasses industrial production, CNC equipment operation, maintenance, and troubleshooting. His work connects control-system analysis and simulation with an understanding of industrial operations.',
 profiles: [ ['ORCID','https://orcid.org/0009-0009-8078-8910'],['Google Scholar','https://scholar.google.com/citations?user=hNu7HPkAAAAJ'],['Scopus','https://www.scopus.com/authid/detail.uri?authorId=58567498100'],['LinkedIn','https://www.linkedin.com/in/ahmed-iqdymat'],['GitHub','https://github.com/AHMED-IQDYMAT'] ],
 education: [ {date:'2021–Present',url:'https://upb.ro/',title:'PhD in Systems Engineering',institution:'National University of Science and Technology POLITEHNICA Bucharest',detail:'In progress · Department of Automation and Industrial Informatics · Romania'}, {date:'2016–2018',title:'Master’s Degree in Automation and Industrial Informatics',url:'https://www.univ-dbkm.dz/en/home/',institution:'Djilali Bounaama University of Khemis Miliana',detail:'Algeria'}, {date:'2011–2016',title:'Bachelor’s Degree in Automation',url:'https://www.univ-dbkm.dz/en/home/',institution:'Djilali Bounaama University of Khemis Miliana',detail:'Algeria'} ],
 experience: [ {date:'Jun–Nov 2021',title:'Industrial Automation & Maintenance Engineer',institution:'TB Lock — Safety Door Manufacturing',detail:'Hebron, West Bank',description:'Supported manufacturing operations, CNC equipment operation, preventive and corrective maintenance, and equipment troubleshooting.'},{date:'Jan 2019–Dec 2020',title:'Operation and Maintenance Engineer',url:'https://www.al-jebrini.com/',institution:'Al Jebrini Dairy & Food Industries',detail:'Hebron, West Bank',description:'Operated industrial production machinery and supported maintenance, production continuity, and safe equipment operation.'} ]
};
export const themes = [
 ['Automation & Control Systems','System-level approaches to industrial automation, control-system design, and the analysis of dynamic behaviour.'],
 ['Intelligent & Learning-Based Control','Learning-based, model-based, and optimal control methods for dynamic systems and intelligent automation.'],
 ['Robotics & Motion Control','Simulation-based investigation of manipulator motion, waypoint tracking, trajectory optimisation, and pick-and-place tasks.'],
 ['Modelling, Simulation & Validation','Modelling dynamic systems and using simulation, testing, and engineering analysis to evaluate controller behaviour and implementation constraints.']
];
export const skills = [
 ['Control & Systems',['Control Systems','Systems Engineering','System Modelling','System Simulation','LQR','Intelligent Control','Optimal Control']],
 ['AI & Intelligent Systems',['Artificial Intelligence','Reinforcement Learning','Soft Actor-Critic']],
 ['Robotics & Automation',['Robot Manipulators','Industrial Automation','Motion Control','Pick-and-Place Systems']],
 ['Engineering Software & Programming',['MATLAB','Simulink','Python (Basic)','ROS 2','URSim']],
 ['Engineering Workflow',['Simulation','Testing','Validation','Technical Documentation','Engineering Analysis']]
];
export const software = {name:'Hybrid SAC–LQR Control for UR3e',version:'1.0.0',url:'https://github.com/AHMED-IQDYMAT/Hybrid-SAC-LQR-UR3e',doi:'10.5281/zenodo.22817235'};

export const languages = [['Arabic','Native'],['English','Advanced'],['Romanian','Basic'],['French','Intermediate']];
export const navigation = [['overview','Academic Profile'],['qualifications','Academic Qualifications'],['experience','Professional Experience'],['research','Research Interests'],['publications','Publications'],['expertise','Technical Expertise'],['languages','Languages'],['profiles','Academic Profiles'],['contact','CV & Contact']];
