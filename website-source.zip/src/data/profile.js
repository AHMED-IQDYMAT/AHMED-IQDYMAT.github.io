export const profile = {
 name: 'Ahmed Iqdymat', title: 'Automation & Control Systems Engineer', status: 'PhD Candidate in Systems Engineering',
 institution: 'National University of Science and Technology POLITEHNICA Bucharest', department: 'Department of Automation and Industrial Informatics', location: 'Bucharest, Romania', email: 'ahmed.iqdymat@stud.acs.upb.ro', portrait: '/images/ahmed-iqdymat.jpeg',
 introduction: 'Automation and Control Systems Engineer and PhD candidate in Systems Engineering, investigating the integration of learning-based and model-based control. His research spans automation, intelligent control, reinforcement learning, and system modelling and simulation, with applications to industrial robotic manipulators.',
 biography: 'His academic work examines control-system design, simulation-based evaluation, and MATLAB–ROS integration. Alongside research, his professional background includes industrial production, CNC equipment operation, maintenance, and troubleshooting.',
 profiles: [ ['ORCID','https://orcid.org/0009-0009-8078-8910'],['Google Scholar','https://scholar.google.com/citations?user=hNu7HPkAAAAJ'],['Scopus','https://www.scopus.com/authid/detail.uri?authorId=58567498100'],['LinkedIn','https://www.linkedin.com/in/ahmed-iqdymat'],['GitHub','https://github.com/AHMED-IQDYMAT'] ],
 education: [ {date:'In progress',title:'PhD in Systems Engineering',institution:'National University of Science and Technology POLITEHNICA Bucharest',detail:'Department of Automation and Industrial Informatics · Romania'}, {date:'2016–2018',title:'Master’s Degree in Automation and Industrial Informatics',institution:'Djilali Bounaama University of Khemis Miliana',detail:'Algeria'}, {date:'2011–2016',title:'Bachelor’s Degree in Automation',institution:'Djilali Bounaama University of Khemis Miliana',detail:'Algeria'} ],
 experience: [ {date:'Jun–Nov 2021',title:'Industrial Automation & Maintenance Engineer',institution:'TB Lock — Safety Door Manufacturing',detail:'Hebron, West Bank',description:'Supported manufacturing operations, CNC equipment operation, preventive and corrective maintenance, and equipment troubleshooting.'},{date:'Jan 2019–Dec 2020',title:'Operation and Maintenance Engineer',institution:'Al Jebrini Dairy & Food Industries',detail:'Hebron, West Bank',description:'Operated industrial production machinery and supported maintenance, production continuity, and safe equipment operation.'} ]
};
export const themes = [
 ['Automation & Control Systems','System-level approaches to industrial automation, control-system design, and the analysis of dynamic behaviour.'],
 ['Intelligent & Learning-Based Control','Integration of reinforcement learning and model-based control, including Soft Actor-Critic and linear-quadratic regulation.'],
 ['Robotics & Motion Control','Simulation-based investigation of manipulator motion, waypoint tracking, trajectory optimisation, and pick-and-place tasks.'],
 ['Modelling, Simulation & Validation','System modelling, controller evaluation, and sim-to-sim integration to examine performance and implementation constraints.']
];
export const skills = [
 ['Control & Systems',['Control Systems','System Modelling','System Simulation','LQR','Intelligent Control','Optimal Control']],
 ['AI & Intelligent Systems',['Artificial Intelligence','Reinforcement Learning','Soft Actor-Critic']],
 ['Robotics & Automation',['Robot Manipulators','Industrial Automation','Motion Control','Pick-and-Place Systems']],
 ['Engineering Software',['MATLAB','Simulink','ROS 2','URSim']],
 ['Engineering Workflow',['Simulation','Testing','Validation','Technical Documentation','Engineering Analysis']]
];
export const software = {name:'Hybrid SAC–LQR Control for UR3e',version:'1.0.0',url:'https://github.com/AHMED-IQDYMAT/Hybrid-SAC-LQR-UR3e',doi:'10.5281/zenodo.22817235'};
