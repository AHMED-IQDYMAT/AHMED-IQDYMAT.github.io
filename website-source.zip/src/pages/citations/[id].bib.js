import {publications,bibtex} from '../../data/publications.js';
export function getStaticPaths(){return publications.map(p=>({params:{id:p.id},props:{p}}));}
export function GET({props}){return new Response(bibtex(props.p),{headers:{'Content-Type':'application/x-bibtex; charset=utf-8'}});}
