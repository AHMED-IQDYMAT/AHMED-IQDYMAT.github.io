import { cvPdf, cvFilename, readPublicCV } from '../../data/cv.js';
export function getStaticPaths() {
  return cvPdf ? [{params: {document: cvFilename.replace(/\.pdf$/, '')}}] : [];
}
export function GET() {
  return new Response(readPublicCV(), {headers: {'Content-Type': 'application/pdf'}});
}
