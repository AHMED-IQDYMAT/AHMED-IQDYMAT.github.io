import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {findPublicCV,readPublicCV,cvFilename} from '../src/data/cv.js';

const root=fs.mkdtempSync(path.join(os.tmpdir(),'academic-cv-test-'));
const folder=path.join(root,'cv-upload');
const first=Buffer.from('%PDF-1.4\nfirst test fixture\n%%EOF');
const replacement=Buffer.from('%PDF-1.4\nreplacement test fixture\n%%EOF');
try {
 assert.equal(readPublicCV(root),null);
 fs.writeFileSync(path.join(root,cvFilename),first);
 assert.deepEqual(readPublicCV(root),first);
 fs.mkdirSync(folder);
 assert.throws(()=>findPublicCV(root),/exactly one/);
 const arbitrary=path.join(folder,'My reviewed CV September.PDF');
 fs.writeFileSync(arbitrary,replacement);
 assert.deepEqual(readPublicCV(root),replacement);
 const renamed=path.join(folder,'A completely different name.pdf');
 fs.renameSync(arbitrary,renamed);
 assert.deepEqual(readPublicCV(root),replacement);
 fs.writeFileSync(path.join(folder,'second.pdf'),first);
 assert.throws(()=>readPublicCV(root),/exactly one/);
 fs.unlinkSync(path.join(folder,'second.pdf'));
 fs.writeFileSync(renamed,'not a PDF');
 assert.throws(()=>readPublicCV(root),/complete PDF/);
 fs.writeFileSync(renamed,Buffer.alloc(10*1024*1024+1));
 assert.throws(()=>readPublicCV(root),/under 10 MB/);
 fs.unlinkSync(renamed);
 fs.symlinkSync(path.join(root,cvFilename),renamed);
 assert.throws(()=>readPublicCV(root),/regular PDF/);
 console.log('PASS: arbitrary names, case-insensitive extension, replacement, legacy compatibility, empty/ambiguous/invalid/oversize/symlink rejection.');
} finally {
 fs.rmSync(root,{recursive:true,force:true});
}
