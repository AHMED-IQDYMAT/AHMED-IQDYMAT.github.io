from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
files = [root / name for name in ["package.json", "package-lock.json", "astro.config.mjs", "README.md", "REVIEW.md"]]
for folder in ["src", "public", "scripts", ".github"]:
    files.extend(p for p in (root / folder).rglob("*") if p.is_file() and "__pycache__" not in p.parts and not p.name.startswith("__qa"))
with ZipFile(root / "website-source.zip", "w", ZIP_DEFLATED) as archive:
    for p in sorted(set(files)):
        archive.write(p, p.relative_to(root))
print(f"Packaged {len(set(files))} reviewed source files.")
