import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {profile,skills,languages} from '../src/data/profile.js';import {publications,bibtex} from '../src/data/publications.js';
const root='dist';const files=fs.readdirSync(root,{recursive:true}).filter(f=>f.endsWith('.html'));
assert(files.includes('index.html'));assert(files.includes('cv/index.html'));assert(files.includes('404.html'));
for(const file of files){const html=fs.readFileSync(path.join(root,file),'utf8');assert(html.includes('lang="en"'));assert(html.includes('rel="canonical"'));assert(html.includes('application/ld+json'));assert.equal((html.match(/<h1[ >]/g)||[]).length,1);assert(!html.includes('+49 175'));assert(!/tel:|Splaiul|password|BEGIN PRIVATE KEY/i.test(html));for(const [,href] of html.matchAll(/href="([^"]+)"/g)){if(!href.startsWith('/')||href.startsWith('//'))continue;const [pathname,hash]=href.split('#');let local=path.join(root,pathname);if(fs.existsSync(local)&&fs.statSync(local).isDirectory())local=path.join(local,'index.html');assert(fs.existsSync(local),`${file}: missing ${href}`);if(hash){assert(fs.readFileSync(local,'utf8').includes(`id="${hash}"`),`Missing anchor ${href}`);}}}
assert(fs.existsSync('dist/sitemap.xml'));assert(fs.readFileSync('dist/robots.txt','utf8').includes('Sitemap:'));
for(const p of publications){assert(p.title&&p.authors.length&&p.year&&p.venue);assert.equal(fs.readFileSync(`dist/citations/${p.id}.bib`,'utf8'),bibtex(p));}
assert.equal(new Set(publications.map(p=>p.id)).size,publications.length);assert(publications.every((p,i)=>i===0||publications[i-1].year>=p.year));
console.log(`PASS: ${files.length} HTML routes, internal links/anchors, metadata, privacy, sitemap, robots, and ${publications.length} citation exports.`);

const home=fs.readFileSync('dist/index.html','utf8');
for(const token of ['AHMED IQDYMAT','mailto:Ahmed.Iqdymat@gmail.com','mailto:ahmed.iqdymat@stud.acs.upb.ro','id="languages"','id="profiles"','Python','10.1109/CSCS59211.2023.00011','authorId=58567498100']) assert(home.includes(token),`Missing ${token}`);
assert(!home.includes('↗'));assert.equal(home.includes('Download CV (PDF)'),Boolean(profile.cvPdf));
const schemas=[...home.matchAll(/<script type="application\/ld\+json">(.*?)<\/script>/gs)];for(const [,data] of schemas){const graph=JSON.parse(data)['@graph'];assert.equal(graph.filter(x=>x['@type']==='ScholarlyArticle').length,publications.length);assert(graph.some(x=>x['@type']==='SoftwareSourceCode'&&x.identifier==='10.5281/zenodo.22817235'));}
console.log('PASS: revised academic content, approved emails, conditional PDF download, separate scholarly identifiers.');

for(const file of files){const html=fs.readFileSync(path.join(root,file),'utf8');const emails=html.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/gi)||[];assert(emails.every(e=>[profile.email,profile.professionalEmail].map(v=>v.toLowerCase()).includes(e.toLowerCase())),`Unapproved email in ${file}`);}

assert(home.includes('2021–Present'));
assert(!fs.existsSync('dist/cv/update/index.html'));
for(const file of files){
 const html=fs.readFileSync(path.join(root,file),'utf8');
 assert(!/\/cv\/update|Update your CV|Website owner|Commit changes|upload instructions|sign.in instructions|cv-upload|10 MB|rebuilds automatically|upload \/ replace/i.test(html),`Owner instructions leaked into ${file}`);
 assert(!/github\.com\/AHMED-IQDYMAT\/AHMED-IQDYMAT.github.io\/(upload|edit|actions)/i.test(html),`Admin link in ${file}`);
}
const cv=fs.readFileSync('dist/cv/index.html','utf8');

// CV V13 skills and languages must render consistently on the homepage and HTML CV.
assert.deepEqual(skills.map(([category])=>category), [
 'Scientific Research & Publishing', 'Engineering & Simulation',
 'Scientific Documentation & Software', 'Additional Technical & Industrial Skills'
]);
assert.equal(skills.reduce((sum,[,items])=>sum+items.length,0),35);
assert.deepEqual(languages,[['Arabic','Native'],['English','Fluent'],['French','Intermediate'],['Romanian','Basic']]);
for(const [pageName,rendered] of [['homepage',home],['HTML CV',cv]]) {
 const html=rendered.replace(/&(?:amp|#38|#x26);/gi,'&');
 assert(html.includes('Technical & Academic Skills'),pageName+': missing section title');
 for(const [category,items] of skills) {
   assert(html.includes(category),pageName+': missing category '+category);
   for(const item of items) assert(html.includes(item),pageName+': missing skill '+item);
 }
 for(const [name,level] of languages) {
   assert(html.includes(name),pageName+': missing language '+name);
   assert(html.includes(level),pageName+': missing language level '+level);
 }
}
console.log('PASS: CV V13 skills and language levels match on both HTML pages.');

assert(home.includes('href="/cv/"'));
assert(cv.includes('data-print'));
assert(cv.includes('Last updated:'));
if(profile.cvPdf){
 assert.equal(profile.cvPdf,'/cv/Ahmed-Iqdymat-Academic-CV.pdf');
 assert(home.includes(profile.cvPdf)&&cv.includes(profile.cvPdf));
 const {readPublicCV}=await import('../src/data/cv.js');
 assert.deepEqual(fs.readFileSync(path.join(root,profile.cvPdf)),readPublicCV());
}
await import('./cv-workflow.test.mjs');
console.log('PASS: public CV controls, stable PDF bytes, and no public maintenance page or instructions.');
