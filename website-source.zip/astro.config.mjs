import { defineConfig } from 'astro/config';
export default defineConfig({site:'https://ahmed-iqdymat.github.io',devToolbar:{enabled:false},output:'static',trailingSlash:'always',server:{host:true},vite:{server:{allowedHosts:['terminal.local']}}});
